"""Tests for the new behaviour. Each one is the 'after' for a legacy characterisation test (R2, R4, R5, R15a).

Run: pytest -q   (no servers needed: the legacy DB is a temp copy and the partners are an in-process fake)
"""
import asyncio
import datetime as dt
import hashlib
import os
import sqlite3

import httpx
import pytest

os.environ["VASTRA_ENV"] = "dev"
os.environ.pop("VASTRA_API_KEYS", None)

from vastra_api import config, db, partners, pricing  # noqa: E402
from vastra_api.legacy_catalogue import Product  # noqa: E402

WEB, APP, POS, WMS, ERP = "dev-web-key", "dev-app-key", "dev-pos-key", "dev-wms-key", "dev-erp-key"
PRIYA, RAVI = "dev-priya-key", "dev-ravi-key"


# ------------------------------------------------------------------ fake partner APIs
class FakePartners:
    def __init__(self):
        self.charges, self.courier_delay, self.payment_status = [], 0.0, "success"

    async def handler(self, request: httpx.Request):
        if request.url.path == "/courier/promise":
            await asyncio.sleep(self.courier_delay)
            return httpx.Response(200, json={"delivery_days": 2, "cod_available": True})
        if request.url.path == "/payment/charge":
            if self.payment_status == "success":
                self.charges.append(request.content)
                return httpx.Response(200, json={"status": "success", "charge_id": len(self.charges)})
            return httpx.Response(200, json={"status": "failed", "reason": "bank_declined"})
        return httpx.Response(404)


# ------------------------------------------------------------------ fixtures
def make_legacy_db(path, sale_ends):
    con = sqlite3.connect(path)
    con.executescript("""
    CREATE TABLE products (sku TEXT PRIMARY KEY, name TEXT, category TEXT, base_price INT,
                           sale_price INT, sale_ends_utc TEXT, member_discount_pct INT);
    CREATE TABLE stock_copy (sku TEXT PRIMARY KEY, qty INT, copied_at TEXT);
    """)
    con.execute("INSERT INTO products VALUES ('SKU00003','Linen kurta','kurtas',2000,1600,?,10)", (sale_ends,))
    con.execute("INSERT INTO products VALUES ('SKU00007','Denim jacket','jeans',3000,NULL,NULL,10)")
    con.execute("INSERT INTO stock_copy VALUES ('SKU00003',5,'2026-11-07T08:00:00+00:00')")
    con.execute("INSERT INTO stock_copy VALUES ('SKU00007',1,'2026-11-07T08:00:00+00:00')")
    con.commit(); con.close()


@pytest.fixture()
def env(tmp_path):
    legacy = tmp_path / "legacy.db"
    make_legacy_db(legacy, (dt.datetime.now(dt.timezone.utc) + dt.timedelta(hours=2)).isoformat())
    os.environ["LEGACY_DB_PATH"] = str(legacy)
    os.environ["VASTRA_DB_PATH"] = str(tmp_path / "modern.db")
    os.environ["COURIER_TIMEOUT_S"] = "0.3"
    config.reload_settings()
    db.init()
    from vastra_api import stock
    stock.bootstrap_from_legacy()
    fake = FakePartners()
    partners.set_client(httpx.AsyncClient(transport=httpx.MockTransport(fake.handler), base_url="http://partners"))
    from vastra_api.main import app
    yield {"app": app, "fake": fake, "legacy": legacy}
    partners.set_client(None)


def run(env, *calls):
    """Run one or more requests concurrently against the ASGI app."""
    async def go():
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=env["app"]), base_url="http://t") as c:
            return await asyncio.gather(*[c.request(m, u, **kw) for m, u, kw in calls])
    res = asyncio.run(go())
    return res[0] if len(res) == 1 else res


def h(key, **extra):
    return {"X-API-Key": key, **extra}


BUY = {"sku": "SKU00003", "qty": 1, "coupon_pct": 10, "member": True}


# ------------------------------------------------------------------ R4: one price
def test_every_channel_gets_the_same_price_and_breakdown(env):
    prices = [run(env, ("GET", "/v1/prices/SKU00003?coupon_pct=10&member=true", {"headers": h(k)})).json()
              for k in (WEB, APP, POS)]
    assert {p["unit_price"] for p in prices} == {1296}        # legacy gave 1296 / 1440 / 1600
    assert prices[0]["breakdown"] == prices[1]["breakdown"] == prices[2]["breakdown"]
    assert prices[0]["policy_version"] == pricing.POLICY_VERSION


def test_sale_ends_at_the_same_utc_instant_everywhere():
    ends = dt.datetime(2026, 11, 7, 14, 0, tzinfo=dt.timezone.utc)
    p = Product(sku="X", name="x", category="c", base_price=2000, sale_price=1600, sale_ends_at=ends,
                member_discount_pct=10)
    assert pricing.quote(p, now=ends - dt.timedelta(seconds=1)).unit_price == 1600
    assert pricing.quote(p, now=ends + dt.timedelta(hours=1)).unit_price == 2000   # legacy app still said 1600


# ------------------------------------------------------------------ R2: checkout
def test_checkout_places_order_moves_stock_and_emits_event(env):
    r = run(env, ("POST", "/v1/checkout", {"json": BUY, "headers": h(WEB, **{"Idempotency-Key": "order-0001"})}))
    assert r.status_code == 201, r.text
    body = r.json()
    assert body["status"] == "paid" and body["total"] == 1296
    assert run(env, ("GET", "/v1/stock/SKU00003", {"headers": h(WEB)})).json()["on_hand"] == 4
    ev = run(env, ("GET", "/v1/integration/events", {"headers": h(ERP)})).json()["events"]
    assert ev[-1]["type"] == "order.placed" and ev[-1]["payload"]["order_id"] == body["order_id"]


def test_retry_with_same_idempotency_key_charges_once(env):
    call = ("POST", "/v1/checkout", {"json": BUY, "headers": h(APP, **{"Idempotency-Key": "retry-after-timeout"})})
    first, second = run(env, call), run(env, call)
    assert first.status_code == second.status_code == 201
    assert first.json()["order_id"] == second.json()["order_id"]
    assert second.json()["idempotent_replay"] is True
    assert len(env["fake"].charges) == 1                      # legacy charged twice


def test_reusing_a_key_for_a_different_basket_is_rejected(env):
    k = {"Idempotency-Key": "same-key-123"}
    run(env, ("POST", "/v1/checkout", {"json": BUY, "headers": h(WEB, **k)}))
    r = run(env, ("POST", "/v1/checkout", {"json": {**BUY, "qty": 2}, "headers": h(WEB, **k)}))
    assert r.status_code == 422


def test_slow_courier_is_cut_off_and_checkout_still_completes(env):
    env["fake"].courier_delay = 5.0                           # legacy: request hangs with timeout=None
    r = run(env, ("POST", "/v1/checkout", {"json": BUY, "headers": h(WEB, **{"Idempotency-Key": "slow-courier"})}))
    body = r.json()
    assert r.status_code == 201
    assert body["delivery_estimated"] is True and body["delivery_days"] == config.settings.fallback_delivery_days
    assert body["trace"]["courier_ms"] < 600


def test_steps_run_in_parallel(env):
    env["fake"].courier_delay = 0.2
    body = run(env, ("POST", "/v1/checkout", {"json": BUY, "headers": h(WEB, **{"Idempotency-Key": "par-0001"})})).json()
    t = body["trace"]
    assert t["courier_ms"] >= 190
    assert t["parallel_block_ms"] < t["courier_ms"] + 60      # bounded by the slowest step, not the sum (legacy: sum)


def test_payment_failure_releases_the_reservation(env):
    env["fake"].payment_status = "failed"
    r = run(env, ("POST", "/v1/checkout", {"json": BUY, "headers": h(WEB, **{"Idempotency-Key": "declined-01"})}))
    assert r.status_code == 402
    s = run(env, ("GET", "/v1/stock/SKU00003", {"headers": h(WEB)})).json()
    assert s["reserved"] == 0 and s["on_hand"] == 5


# ------------------------------------------------------------------ R5: live stock, no oversell
def test_last_unit_cannot_be_sold_twice(env):
    buy = {"sku": "SKU00007", "qty": 1}
    a, b = run(env,
               ("POST", "/v1/checkout", {"json": buy, "headers": h(WEB, **{"Idempotency-Key": "race-aaaa"})}),
               ("POST", "/v1/checkout", {"json": buy, "headers": h(APP, **{"Idempotency-Key": "race-bbbb"})}))
    assert sorted([a.status_code, b.status_code]) == [201, 409]
    assert run(env, ("GET", "/v1/stock/SKU00007", {"headers": h(WEB)})).json()["available"] == 0


def test_store_sale_events_update_stock_immediately_and_only_once(env):
    ev = [{"sku": "SKU00003", "kind": "store_sale", "qty": 2, "ref": "ST012-TILL3-000981"}]
    first = run(env, ("POST", "/v1/stock/events", {"json": ev, "headers": h(POS)})).json()
    again = run(env, ("POST", "/v1/stock/events", {"json": ev, "headers": h(POS)})).json()
    assert first["applied"] == 1 and again["duplicates_ignored"] == 1
    assert run(env, ("GET", "/v1/stock/SKU00003", {"headers": h(WEB)})).json()["on_hand"] == 3


# ------------------------------------------------------------------ R15a: identity, roles, audit
def test_calls_without_a_key_or_role_are_refused(env):
    assert run(env, ("GET", "/v1/prices/SKU00003", {})).status_code == 401
    ev = [{"sku": "SKU00003", "kind": "receipt", "qty": 1, "ref": "x1"}]
    assert run(env, ("POST", "/v1/stock/events", {"json": ev, "headers": h(WEB)})).status_code == 403


def test_price_override_is_named_audited_and_applied_only_in_that_store(env):
    o = {"sku": "SKU00003", "store": "ST012", "price": 1500, "reason": "damaged display piece"}
    assert run(env, ("POST", "/v1/admin/price-overrides", {"json": o, "headers": h(POS)})).status_code == 403
    r = run(env, ("POST", "/v1/admin/price-overrides", {"json": o, "headers": h(RAVI)}))
    assert r.status_code == 201 and r.json()["created_by"] == "ravi.kumar@ST012"
    assert run(env, ("GET", "/v1/prices/SKU00003?store=ST012", {"headers": h(POS)})).json()["unit_price"] == 1500
    assert run(env, ("GET", "/v1/prices/SKU00003?store=ST013", {"headers": h(POS)})).json()["unit_price"] == 1600
    audit = run(env, ("GET", "/v1/admin/audit", {"headers": h(PRIYA)})).json()
    assert audit[0]["actor"] == "ravi.kumar@ST012" and audit[0]["detail"]["reason"] == "damaged display piece"


# ------------------------------------------------------------------ R1 + strangler safety
def test_product_reads_are_cacheable(env):
    r = run(env, ("GET", "/v1/products/SKU00003", {"headers": h(WEB)}))
    assert "max-age" in r.headers["cache-control"] and r.headers["etag"]
    r2 = run(env, ("GET", "/v1/products/SKU00003", {"headers": h(WEB, **{"If-None-Match": r.headers["etag"]})}))
    assert r2.status_code == 304


def test_new_api_never_writes_to_the_legacy_database(env):
    before = hashlib.sha256(env["legacy"].read_bytes()).hexdigest()
    run(env, ("POST", "/v1/checkout", {"json": BUY, "headers": h(WEB, **{"Idempotency-Key": "legacy-safe"})}))
    assert hashlib.sha256(env["legacy"].read_bytes()).hexdigest() == before


def test_request_id_from_gateway_is_echoed(env):
    r = run(env, ("GET", "/v1/health", {"headers": {"X-Request-ID": "gw-123"}}))
    assert r.headers["x-request-id"] == "gw-123"
