"""Vastra API v1 — the new front door behind the existing NGINX gateway (gateway/nginx.conf: /v1/* -> :8200).

Run:  uvicorn vastra_api.main:app --port 8200
Docs: http://localhost:8200/docs  (OpenAPI contract the app, web and POS teams code against)
"""
import logging
import time
import uuid
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request

from vastra_api import __version__, db, legacy_catalogue, stock
from vastra_api.routers import catalogue, checkout, stock_admin

log = logging.getLogger("vastra_api")
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")


@asynccontextmanager
async def lifespan(_app):
    db.init()
    try:
        n = stock.bootstrap_from_legacy()
        if n:
            log.info("stock ledger bootstrapped from legacy stock_copy: %s rows", n)
    except legacy_catalogue.LegacyUnavailable as e:
        log.warning("%s", e)
    yield


app = FastAPI(
    title="Vastra API",
    version=__version__,
    description="Versioned REST APIs that strangle the 2014 monolith one capability at a time: "
                "catalogue, one price, live stock, parallel idempotent checkout, audited overrides and an "
                "integration event feed.",
    lifespan=lifespan,
)


@app.middleware("http")
async def request_context(request: Request, call_next):
    # The gateway sets X-Request-ID; keep it (or create one) so a request can be followed end to end.
    rid = request.headers.get("x-request-id") or uuid.uuid4().hex
    request.state.request_id = rid
    t0 = time.perf_counter()
    response = await call_next(request)
    ms = round((time.perf_counter() - t0) * 1000)
    response.headers["X-Request-ID"] = rid
    response.headers["Server-Timing"] = f"app;dur={ms}"
    log.info("rid=%s %s %s %s %sms", rid, request.method, request.url.path, response.status_code, ms)
    return response


@app.get("/v1/health", tags=["ops"])
def health():
    return {"status": "ok", "version": __version__}


app.include_router(catalogue.router)
app.include_router(checkout.router)
app.include_router(stock_admin.router)
