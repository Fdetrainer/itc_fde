"""Per-client, per-person API keys with roles (replaces the single shared login and shared override code, R15a).

Every caller is identified: a channel (web, app, pos, wms, erp, back-office) and, for people, a named user.
The gateway (NGINX) adds X-Request-ID; we carry it into logs and the audit trail.
"""
from dataclasses import dataclass
from typing import Optional

from fastapi import Depends, Header, HTTPException, Request

from vastra_api import config


@dataclass
class Principal:
    client: str
    user: Optional[str]
    roles: list

    @property
    def actor(self) -> str:
        return self.user or f"service:{self.client}"


def principal(x_api_key: Optional[str] = Header(default=None)) -> Principal:
    if not x_api_key:
        raise HTTPException(401, "missing X-API-Key", headers={"WWW-Authenticate": "ApiKey"})
    entry = config.settings.api_keys.get(x_api_key)
    if not entry:
        raise HTTPException(401, "unknown API key", headers={"WWW-Authenticate": "ApiKey"})
    return Principal(client=entry["client"], user=entry.get("user"), roles=list(entry.get("roles", [])))


def require(role: str):
    def check(p: Principal = Depends(principal)) -> Principal:
        if role not in p.roles:
            raise HTTPException(403, f"role '{role}' required")
        return p
    return check


def request_id(request: Request) -> str:
    return request.state.request_id
