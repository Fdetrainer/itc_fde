"""Settings come from environment variables, never from a file committed to the repo (fixes R15a).

Copy .env.example to .env for local work; in production inject these from a secret store.
"""
import json
import os
import warnings
from dataclasses import dataclass, field

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# Development-only keys. Used ONLY when VASTRA_ENV=dev and VASTRA_API_KEYS is not set.
_DEV_KEYS = {
    "dev-web-key":   {"client": "web",       "user": None,          "roles": ["read", "checkout"]},
    "dev-app-key":   {"client": "app",       "user": None,          "roles": ["read", "checkout"]},
    "dev-pos-key":   {"client": "pos",       "user": None,          "roles": ["read", "stock:write"]},
    "dev-wms-key":   {"client": "wms",       "user": None,          "roles": ["read", "stock:write"]},
    "dev-erp-key":   {"client": "erp",       "user": None,          "roles": ["integration:read"]},
    "dev-priya-key": {"client": "back-office", "user": "priya.menon", "roles": ["read", "price:override", "audit:read"]},
    "dev-ravi-key":  {"client": "pos",       "user": "ravi.kumar@ST012", "roles": ["read", "price:override"]},
}


@dataclass
class Settings:
    env: str = field(default_factory=lambda: os.getenv("VASTRA_ENV", "dev"))
    db_path: str = field(default_factory=lambda: os.getenv("VASTRA_DB_PATH", os.path.join(ROOT, "data", "modern.db")))
    # Read-only path to the legacy monolith database (strangler pattern: we read it, never write it).
    legacy_db_path: str = field(default_factory=lambda: os.getenv(
        "LEGACY_DB_PATH", os.path.join(ROOT, "..", "vastra-legacy-lab", "data", "vastra_legacy.db")))
    partner_base_url: str = field(default_factory=lambda: os.getenv("PARTNER_BASE_URL", "http://127.0.0.1:8100"))
    courier_timeout_s: float = field(default_factory=lambda: float(os.getenv("COURIER_TIMEOUT_S", "0.8")))
    payment_timeout_s: float = field(default_factory=lambda: float(os.getenv("PAYMENT_TIMEOUT_S", "3.0")))
    fallback_delivery_days: int = field(default_factory=lambda: int(os.getenv("FALLBACK_DELIVERY_DAYS", "4")))
    product_cache_seconds: int = field(default_factory=lambda: int(os.getenv("PRODUCT_CACHE_SECONDS", "60")))
    api_keys: dict = field(default_factory=dict)

    def __post_init__(self):
        raw = os.getenv("VASTRA_API_KEYS")
        if raw:
            self.api_keys = json.loads(raw)
        elif self.env == "dev":
            warnings.warn("VASTRA_API_KEYS not set: using built-in development keys (dev only).")
            self.api_keys = dict(_DEV_KEYS)
        else:
            raise RuntimeError("VASTRA_API_KEYS must be set outside development")


settings = Settings()


def reload_settings() -> Settings:
    """Re-read the environment (used by tests)."""
    global settings
    settings = Settings()
    return settings
