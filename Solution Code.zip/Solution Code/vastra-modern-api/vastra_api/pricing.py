"""ONE pricing engine for web, app and POS (replaces the three disagreeing copies, R4).

Policy "2026-11-v1" (to be confirmed by Vastra's pricing team; each rule is a named flag, not hidden code):
  1. An active store price override (named, audited, time-limited) wins outright.
  2. The sale price applies while now < sale_ends_at, compared in UTC.
  3. A coupon stacks on top of the sale price.
  4. The member discount is applied last.
  5. Money is rounded once, at the end, half-up to the rupee.
Every quote returns the breakdown and the policy version, so a customer, a store and support see the same lines.
"""
import datetime as dt
from decimal import Decimal, ROUND_HALF_UP
from typing import Optional

from pydantic import BaseModel

from vastra_api.legacy_catalogue import Product

POLICY_VERSION = "2026-11-v1"
COUPON_STACKS_WITH_SALE = True
MEMBER_DISCOUNT_LAST = True


class PriceLine(BaseModel):
    step: str
    amount: str      # running unit price after this step (string, so no float drift)


class Quote(BaseModel):
    sku: str
    unit_price: int
    currency: str = "INR"
    policy_version: str = POLICY_VERSION
    on_sale: bool
    override_id: Optional[int] = None
    breakdown: list[PriceLine]


def _pct_off(value: Decimal, pct: int) -> Decimal:
    return value * (Decimal(100) - Decimal(pct)) / Decimal(100)


def quote(product: Product, coupon_pct: int = 0, member: bool = False,
          now: Optional[dt.datetime] = None, override: Optional[dict] = None) -> Quote:
    now = (now or dt.datetime.now(dt.timezone.utc)).astimezone(dt.timezone.utc)
    if not 0 <= coupon_pct <= 90:
        raise ValueError("coupon_pct must be between 0 and 90")

    if override:
        return Quote(sku=product.sku, unit_price=int(override["price"]), on_sale=False,
                     override_id=override["override_id"],
                     breakdown=[PriceLine(step=f"store override #{override['override_id']}", amount=str(override["price"]))])

    unit = Decimal(product.base_price)
    lines = [PriceLine(step="base price", amount=str(unit))]

    on_sale = bool(product.sale_price and product.sale_ends_at and now < product.sale_ends_at)
    if on_sale:
        unit = Decimal(product.sale_price)
        lines.append(PriceLine(step=f"sale price (ends {product.sale_ends_at.isoformat()})", amount=str(unit)))

    def apply_coupon(u):
        if coupon_pct and (COUPON_STACKS_WITH_SALE or not on_sale):
            u = _pct_off(u, coupon_pct)
            lines.append(PriceLine(step=f"coupon {coupon_pct}%", amount=str(u.quantize(Decimal('0.01')))))
        return u

    def apply_member(u):
        if member and product.member_discount_pct:
            u = _pct_off(u, product.member_discount_pct)
            lines.append(PriceLine(step=f"member {product.member_discount_pct}%", amount=str(u.quantize(Decimal('0.01')))))
        return u

    unit = apply_member(apply_coupon(unit)) if MEMBER_DISCOUNT_LAST else apply_coupon(apply_member(unit))
    final = int(unit.quantize(Decimal("1"), rounding=ROUND_HALF_UP))
    lines.append(PriceLine(step="rounded to rupee", amount=str(final)))
    return Quote(sku=product.sku, unit_price=final, on_sale=on_sale, breakdown=lines)
