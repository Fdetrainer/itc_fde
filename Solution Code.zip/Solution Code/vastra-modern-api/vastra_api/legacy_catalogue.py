"""Anti-corruption layer over the legacy monolith database.

The new API reads the 2014 `products` and `stock_copy` tables READ-ONLY (SQLite `mode=ro`) and translates
rows into clean models. Nothing in the new service writes to the legacy database, so the monolith keeps
working unchanged while traffic moves to /v1 one capability at a time.
"""
import datetime as dt
import os
import sqlite3
from typing import Optional

from pydantic import BaseModel

from vastra_api import config


class Product(BaseModel):
    sku: str
    name: str
    category: str
    base_price: int
    sale_price: Optional[int] = None
    sale_ends_at: Optional[dt.datetime] = None   # always timezone-aware UTC
    member_discount_pct: int = 0


class LegacyUnavailable(RuntimeError):
    pass


def _connect():
    path = os.path.abspath(config.settings.legacy_db_path)
    if not os.path.exists(path):
        raise LegacyUnavailable(f"legacy database not found at {path}; run `python -m app.db` in vastra-legacy-lab")
    con = sqlite3.connect(f"file:{path}?mode=ro", uri=True, timeout=5)
    con.row_factory = sqlite3.Row
    return con


def _to_utc(value: Optional[str]) -> Optional[dt.datetime]:
    if not value:
        return None
    t = dt.datetime.fromisoformat(value)
    # Legacy stores ISO strings; treat a naive value as UTC explicitly instead of guessing local time (R4 bug).
    return t.replace(tzinfo=dt.timezone.utc) if t.tzinfo is None else t.astimezone(dt.timezone.utc)


def get_product(sku: str) -> Optional[Product]:
    con = _connect()
    try:
        row = con.execute("SELECT * FROM products WHERE sku=?", (sku,)).fetchone()
    finally:
        con.close()
    if row is None:
        return None
    return Product(sku=row["sku"], name=row["name"], category=row["category"], base_price=row["base_price"],
                   sale_price=row["sale_price"], sale_ends_at=_to_utc(row["sale_ends_utc"]),
                   member_discount_pct=row["member_discount_pct"] or 0)


def list_products(category: Optional[str], limit: int, offset: int) -> list[Product]:
    con = _connect()
    try:
        q, args = "SELECT * FROM products", []
        if category:
            q += " WHERE category=?"; args.append(category)
        q += " ORDER BY sku LIMIT ? OFFSET ?"; args += [limit, offset]
        rows = con.execute(q, args).fetchall()
    finally:
        con.close()
    return [Product(sku=r["sku"], name=r["name"], category=r["category"], base_price=r["base_price"],
                    sale_price=r["sale_price"], sale_ends_at=_to_utc(r["sale_ends_utc"]),
                    member_discount_pct=r["member_discount_pct"] or 0) for r in rows]


def legacy_stock_snapshot() -> list[tuple[str, int]]:
    """One-time bootstrap of the new stock ledger from the legacy 4-hourly copy."""
    con = _connect()
    try:
        return [(r["sku"], r["qty"]) for r in con.execute("SELECT sku, qty FROM stock_copy")]
    finally:
        con.close()
