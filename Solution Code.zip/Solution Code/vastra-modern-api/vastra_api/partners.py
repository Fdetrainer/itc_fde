"""Adapters for the partner APIs (courier, payment, notify) with timeouts, fallbacks and idempotency (fixes R2).

- Courier: hard timeout (default 0.8 s). On timeout or error we return a conservative estimated promise
  instead of holding the checkout thread (the cause of INC-301 and the SEV1 on 7 Nov).
- Payment: the legacy gateway accepts no idempotency key, so this adapter enforces one. A key that already
  has a recorded result is answered from the record and the gateway is NOT called again (no double charge).
  A timeout is recorded as "unknown" and left for reconciliation rather than retried blindly.
"""
import asyncio
import datetime as dt
import time
from typing import Optional

import httpx

from vastra_api import config, db

_client: Optional[httpx.AsyncClient] = None


def client() -> httpx.AsyncClient:
    global _client
    if _client is None:
        _client = httpx.AsyncClient(base_url=config.settings.partner_base_url,
                                    timeout=httpx.Timeout(config.settings.payment_timeout_s, connect=0.5))
    return _client


def set_client(c: Optional[httpx.AsyncClient]):
    """Inject a client (tests use an in-process fake partner)."""
    global _client
    _client = c


async def courier_promise(pincode: str) -> dict:
    t0 = time.perf_counter()
    limit = config.settings.courier_timeout_s
    try:
        # httpx timeout per phase, plus an overall deadline so a slow trickle can't exceed the budget.
        r = await asyncio.wait_for(
            client().get("/courier/promise", params={"pincode": pincode}, timeout=limit), timeout=limit)
        r.raise_for_status()
        body = r.json()
        return {"delivery_days": body["delivery_days"], "estimated": False,
                "ms": round((time.perf_counter() - t0) * 1000)}
    except (asyncio.TimeoutError, httpx.HTTPError, KeyError, ValueError) as e:
        return {"delivery_days": config.settings.fallback_delivery_days, "estimated": True,
                "fallback_reason": type(e).__name__, "ms": round((time.perf_counter() - t0) * 1000)}


def _now():
    return dt.datetime.now(dt.timezone.utc).isoformat()


async def charge(idempotency_key: str, order_id: str, amount: int) -> dict:
    con = db.connect()
    try:
        prior = con.execute("SELECT * FROM payments WHERE idempotency_key=?", (idempotency_key,)).fetchone()
    finally:
        con.close()
    if prior and prior["status"] in ("success", "unknown"):
        return {"status": prior["status"], "charge_id": prior["charge_id"], "replayed": True}

    try:
        r = await client().post("/payment/charge", json={"order_ref": order_id, "amount": amount},
                                headers={"Idempotency-Key": idempotency_key},
                                timeout=config.settings.payment_timeout_s)
        r.raise_for_status()
        body = r.json()
        status = "success" if body.get("status") == "success" else "failed"
        result = {"status": status, "charge_id": str(body.get("charge_id")) if body.get("charge_id") else None,
                  "reason": body.get("reason")}
    except httpx.TimeoutException:
        result = {"status": "unknown", "charge_id": None, "reason": "gateway_timeout_reconcile"}
    except httpx.HTTPError as e:
        result = {"status": "failed", "charge_id": None, "reason": type(e).__name__}

    with db.tx() as con:
        con.execute("INSERT OR REPLACE INTO payments VALUES (?,?,?,?,?,?,?)",
                    (idempotency_key, order_id, amount, result["status"], result["charge_id"],
                     result.get("reason"), _now()))
    return {**result, "replayed": False}
