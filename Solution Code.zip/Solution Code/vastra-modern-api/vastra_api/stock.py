"""Live stock ledger (replaces the 4-hourly stock_copy, R5).

POS tills and the warehouse push stock events as they happen; checkout reserves stock atomically before
taking payment, so two customers cannot buy the last unit (the oversell behind E8).
"""
import datetime as dt
import sqlite3

from vastra_api import db, legacy_catalogue


class OutOfStock(Exception):
    pass


def _now():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def get(sku: str):
    con = db.connect()
    try:
        r = con.execute("SELECT * FROM stock_levels WHERE sku=?", (sku,)).fetchone()
    finally:
        con.close()
    if r is None:
        return None
    return {"sku": sku, "on_hand": r["on_hand"], "reserved": r["reserved"],
            "available": r["on_hand"] - r["reserved"], "updated_at": r["updated_at"]}


def apply_event(sku: str, delta: int, kind: str, source: str, ref: str) -> dict:
    """Apply one POS/WMS event exactly once. Returns {'applied': bool, ...}."""
    with db.tx() as con:
        try:
            con.execute("INSERT INTO stock_events (sku, delta, kind, source, ref, at) VALUES (?,?,?,?,?,?)",
                        (sku, delta, kind, source, ref, _now()))
        except sqlite3.IntegrityError:
            return {"applied": False, "reason": "duplicate event"}
        if kind == "count":       # absolute stock count from a cycle count: delta is the counted quantity
            con.execute("INSERT INTO stock_levels (sku, on_hand, reserved, updated_at) VALUES (?,?,0,?) "
                        "ON CONFLICT(sku) DO UPDATE SET on_hand=MAX(excluded.on_hand, reserved), updated_at=excluded.updated_at",
                        (sku, max(delta, 0), _now()))
        else:
            con.execute("INSERT INTO stock_levels (sku, on_hand, reserved, updated_at) VALUES (?,?,0,?) "
                        "ON CONFLICT(sku) DO UPDATE SET on_hand=MAX(on_hand + ?, reserved), updated_at=excluded.updated_at",
                        (sku, max(delta, 0), _now(), delta))
    return {"applied": True}


def reserve(con, sku: str, qty: int):
    """Inside the caller's transaction: reserve only if enough is available (single atomic UPDATE)."""
    cur = con.execute("UPDATE stock_levels SET reserved = reserved + ?, updated_at=? "
                      "WHERE sku=? AND on_hand - reserved >= ?", (qty, _now(), sku, qty))
    if cur.rowcount != 1:
        raise OutOfStock(sku)


def release(sku: str, qty: int):
    with db.tx() as con:
        con.execute("UPDATE stock_levels SET reserved = MAX(reserved - ?, 0), updated_at=? WHERE sku=?",
                    (qty, _now(), sku))


def commit_sale(con, sku: str, qty: int, order_id: str):
    """Inside the caller's transaction: turn a reservation into a sale and record the event."""
    con.execute("UPDATE stock_levels SET reserved = reserved - ?, on_hand = on_hand - ?, updated_at=? WHERE sku=?",
                (qty, qty, _now(), sku))
    con.execute("INSERT INTO stock_events (sku, delta, kind, source, ref, at) VALUES (?,?,?,?,?,?)",
                (sku, -qty, "online_sale", "vastra-api", order_id, _now()))


def bootstrap_from_legacy() -> int:
    """Seed the ledger once from the legacy stock_copy. Safe to call repeatedly: only fills an empty ledger."""
    con = db.connect()
    try:
        if con.execute("SELECT COUNT(*) FROM stock_levels").fetchone()[0]:
            return 0
    finally:
        con.close()
    rows = legacy_catalogue.legacy_stock_snapshot()
    with db.tx() as con:
        con.executemany("INSERT OR IGNORE INTO stock_levels (sku, on_hand, reserved, updated_at) VALUES (?,?,0,?)",
                        [(s, q, _now()) for s, q in rows])
    return len(rows)
