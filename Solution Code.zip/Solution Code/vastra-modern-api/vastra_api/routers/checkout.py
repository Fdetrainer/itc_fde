"""/v1/checkout — parallel, time-boxed, idempotent checkout (fixes R2, R5 oversell, E14 nightly orders).

Legacy (app/monolith.py):  cart -> price -> promo -> stock copy -> courier (no timeout) -> charge (no key)
New:                      [price | live stock | courier (0.8 s, fallback)] in parallel
                          -> reserve stock atomically -> charge once per Idempotency-Key
                          -> order + stock sale + outbox event in ONE transaction
"""
import asyncio
import datetime as dt
import hashlib
import json
import time
import uuid
from typing import Literal, Optional

from fastapi import APIRouter, Depends, Header, HTTPException, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field

from vastra_api import db, legacy_catalogue, partners, pricing, stock
from vastra_api.audit import emit
from vastra_api.security import Principal, require

router = APIRouter(prefix="/v1", tags=["checkout"])


class CheckoutIn(BaseModel):
    sku: str
    qty: int = Field(1, ge=1, le=20)
    coupon_pct: int = Field(0, ge=0, le=90)
    member: bool = False
    pincode: str = Field("560001", pattern=r"^\d{6}$")
    channel: Literal["web", "app"] = "web"


def _now():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def _finish(key: str, status_code: int, body: dict) -> JSONResponse:
    with db.tx() as con:
        con.execute("UPDATE idempotency SET status_code=?, response=? WHERE key=?", (status_code, json.dumps(body), key))
    return JSONResponse(body, status_code=status_code)


@router.post("/checkout", responses={402: {"description": "payment failed"}, 409: {"description": "out of stock"}})
async def checkout(c: CheckoutIn, request: Request,
                   idempotency_key: str = Header(..., alias="Idempotency-Key", min_length=8, max_length=100),
                   who: Principal = Depends(require("checkout"))):
    key = f"{who.client}:{idempotency_key}"
    req_hash = hashlib.sha256(c.model_dump_json().encode()).hexdigest()

    # 1. Idempotency: a retry of the same request gets the same answer and is never charged again.
    with db.tx() as con:
        prior = con.execute("SELECT * FROM idempotency WHERE key=?", (key,)).fetchone()
        if prior is None:
            con.execute("INSERT INTO idempotency (key, client, request_hash, created_at) VALUES (?,?,?,?)",
                        (key, who.client, req_hash, _now()))
    if prior is not None:
        if prior["request_hash"] != req_hash:
            raise HTTPException(422, "Idempotency-Key reused with a different request body")
        if prior["response"] is None:
            raise HTTPException(409, "a request with this Idempotency-Key is still in progress")
        body = json.loads(prior["response"]); body["idempotent_replay"] = True
        return JSONResponse(body, status_code=prior["status_code"])

    try:
        return await _process(c, key, request)
    except Exception:
        # Unexpected failure: free the key so the client can retry. A charge already made is still
        # protected, because partners.charge() answers a repeated key from the payments table.
        with db.tx() as con:
            con.execute("DELETE FROM idempotency WHERE key=? AND response IS NULL", (key,))
        raise


async def _process(c: CheckoutIn, key: str, request: Request) -> JSONResponse:
    # 2. Price, live stock and courier promise in parallel; the courier call is time-boxed with a fallback.
    t0 = time.perf_counter()
    trace = {}

    async def timed(name, coro):
        s = time.perf_counter()
        out = await coro
        trace[name] = round((time.perf_counter() - s) * 1000)
        return out

    try:
        product = await asyncio.to_thread(legacy_catalogue.get_product, c.sku)
    except legacy_catalogue.LegacyUnavailable as e:
        return _finish(key, 503, {"error": str(e)})
    if product is None:
        return _finish(key, 404, {"error": f"unknown sku {c.sku}"})

    q, level, promise = await asyncio.gather(
        timed("price_ms", asyncio.to_thread(pricing.quote, product, c.coupon_pct, c.member)),
        timed("stock_ms", asyncio.to_thread(stock.get, c.sku)),
        timed("courier_ms", partners.courier_promise(c.pincode)),
    )
    trace["parallel_block_ms"] = round((time.perf_counter() - t0) * 1000)

    if level is None or level["available"] < c.qty:
        return _finish(key, 409, {"error": "out of stock", "sku": c.sku,
                                  "available": level["available"] if level else 0, "trace": trace})

    # 3. Reserve before charging: the last unit cannot be sold twice.
    order_id = "VO" + uuid.uuid4().hex[:12].upper()
    try:
        with db.tx() as con:
            stock.reserve(con, c.sku, c.qty)
    except stock.OutOfStock:
        return _finish(key, 409, {"error": "out of stock", "sku": c.sku, "trace": trace})

    total = q.unit_price * c.qty
    s = time.perf_counter()
    pay = await partners.charge(key, order_id, total)
    trace["payment_ms"] = round((time.perf_counter() - s) * 1000)

    if pay["status"] == "failed":
        stock.release(c.sku, c.qty)
        return _finish(key, 402, {"error": "payment failed", "reason": pay.get("reason"), "order_id": order_id,
                                  "trace": trace})

    status = "paid" if pay["status"] == "success" else "payment_pending"
    # 4. Order, stock movement and integration event commit together (no nightly batch, no lost orders).
    with db.tx() as con:
        if status == "paid":
            stock.commit_sale(con, c.sku, c.qty, order_id)
        con.execute("INSERT INTO orders VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                    (order_id, _now(), c.channel, c.sku, c.qty, q.unit_price, total, status,
                     q.policy_version, promise["delivery_days"], int(promise["estimated"])))
        emit(con, "order.placed" if status == "paid" else "order.payment_pending",
             {"order_id": order_id, "sku": c.sku, "qty": c.qty, "total": total, "channel": c.channel,
              "pincode": c.pincode, "request_id": request.state.request_id})

    trace["total_ms"] = round((time.perf_counter() - t0) * 1000)
    body = {"order_id": order_id, "status": status, "unit_price": q.unit_price, "total": total,
            "pricing_policy": q.policy_version, "price_breakdown": [l.model_dump() for l in q.breakdown],
            "delivery_days": promise["delivery_days"], "delivery_estimated": promise["estimated"],
            "trace": trace}
    return _finish(key, 201 if status == "paid" else 202, body)
