"""/v1/products and /v1/prices — read APIs over the legacy catalogue, with caching (R1) and one price (R4)."""
import hashlib
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query, Request, Response

from vastra_api import config, db, legacy_catalogue, pricing
from vastra_api.audit import active_override
from vastra_api.security import Principal, require

router = APIRouter(prefix="/v1", tags=["catalogue & pricing"])


def _product_or_404(sku: str) -> legacy_catalogue.Product:
    try:
        p = legacy_catalogue.get_product(sku)
    except legacy_catalogue.LegacyUnavailable as e:
        raise HTTPException(503, str(e))
    if p is None:
        raise HTTPException(404, f"unknown sku {sku}")
    return p


@router.get("/products", response_model=list[legacy_catalogue.Product])
def list_products(category: Optional[str] = None, limit: int = Query(50, ge=1, le=200), offset: int = Query(0, ge=0),
                  _: Principal = Depends(require("read"))):
    try:
        return legacy_catalogue.list_products(category, limit, offset)
    except legacy_catalogue.LegacyUnavailable as e:
        raise HTTPException(503, str(e))


@router.get("/products/{sku}", response_model=legacy_catalogue.Product)
def get_product(sku: str, request: Request, response: Response, _: Principal = Depends(require("read"))):
    p = _product_or_404(sku)
    etag = '"' + hashlib.sha256(p.model_dump_json().encode()).hexdigest()[:16] + '"'
    if request.headers.get("if-none-match") == etag:
        return Response(status_code=304, headers={"ETag": etag})
    response.headers["ETag"] = etag
    # Short shared cache: CDN/gateway can serve product data instead of the monolith rendering it every time (R1).
    response.headers["Cache-Control"] = f"public, max-age={config.settings.product_cache_seconds}, stale-while-revalidate=300"
    return p


@router.get("/prices/{sku}", response_model=pricing.Quote)
def get_price(sku: str, coupon_pct: int = Query(0, ge=0, le=90), member: bool = False,
              store: Optional[str] = Query(None, description="store code, for POS quotes (applies audited overrides)"),
              _: Principal = Depends(require("read"))):
    """The single price every channel uses: website, app and POS get the same answer and breakdown."""
    p = _product_or_404(sku)
    con = db.connect()
    try:
        ov = active_override(con, sku, store)
    finally:
        con.close()
    return pricing.quote(p, coupon_pct, member, override=ov)
