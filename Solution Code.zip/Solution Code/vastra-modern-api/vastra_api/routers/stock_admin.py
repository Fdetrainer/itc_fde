"""/v1/stock (live ledger, R5), /v1/admin (named, audited price overrides, R15a), /v1/integration (outbox, E14)."""
import datetime as dt
import json
from typing import Literal, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from pydantic import BaseModel, Field

from vastra_api import db, legacy_catalogue, stock
from vastra_api.audit import emit, record
from vastra_api.security import Principal, require

router = APIRouter(prefix="/v1")


# ---------------------------------------------------------------- stock
class StockEvent(BaseModel):
    sku: str
    kind: Literal["store_sale", "return", "receipt", "transfer_in", "transfer_out", "count"]
    qty: int = Field(..., ge=0, description="units moved; for kind=count, the counted on-hand quantity")
    ref: str = Field(..., min_length=1, max_length=80, description="the till/WMS transaction id; repeats are ignored")


_SIGN = {"store_sale": -1, "transfer_out": -1, "return": 1, "receipt": 1, "transfer_in": 1, "count": 1}


@router.get("/stock/{sku}", tags=["stock"])
def get_stock(sku: str, _: Principal = Depends(require("read"))):
    level = stock.get(sku)
    if level is None:
        raise HTTPException(404, f"no stock record for {sku}")
    return level


@router.post("/stock/events", tags=["stock"], status_code=202)
def post_stock_events(events: list[StockEvent], request: Request, who: Principal = Depends(require("stock:write"))):
    """POS tills and the warehouse push movements as they happen (replaces the 4-hourly CSV copy)."""
    if len(events) > 500:
        raise HTTPException(413, "max 500 events per call")
    applied = duplicates = 0
    for e in events:
        res = stock.apply_event(e.sku, _SIGN[e.kind] * e.qty, e.kind, who.client, e.ref)
        applied += res["applied"]; duplicates += not res["applied"]
    return {"applied": applied, "duplicates_ignored": duplicates, "request_id": request.state.request_id}


@router.post("/admin/stock/bootstrap-from-legacy", tags=["admin"])
def bootstrap(request: Request, who: Principal = Depends(require("price:override"))):
    """One-time seed of the live ledger from the legacy stock_copy (only fills an empty ledger)."""
    try:
        n = stock.bootstrap_from_legacy()
    except legacy_catalogue.LegacyUnavailable as e:
        raise HTTPException(503, str(e))
    with db.tx() as con:
        record(con, who, "stock.bootstrap", "stock_levels", {"rows": n}, request.state.request_id)
    return {"rows_loaded": n}


# ---------------------------------------------------------------- price overrides + audit
class OverrideIn(BaseModel):
    sku: str
    store: str = Field(..., pattern=r"^ST\d{3}$")
    price: int = Field(..., gt=0)
    reason: str = Field(..., min_length=5, max_length=200)
    valid_minutes: int = Field(60, ge=1, le=24 * 60)


@router.post("/admin/price-overrides", tags=["admin"], status_code=201)
def create_override(o: OverrideIn, request: Request, who: Principal = Depends(require("price:override"))):
    """Replaces the shared MGR-OVERRIDE code: a named person, a reason, an expiry and an audit row."""
    if not who.user:
        raise HTTPException(403, "price overrides need a named user key, not a shared service key")
    p = legacy_catalogue.get_product(o.sku)
    if p is None:
        raise HTTPException(404, f"unknown sku {o.sku}")
    if o.price < p.base_price * 0.5:
        raise HTTPException(422, "override below 50% of base price needs head-office approval")
    now = dt.datetime.now(dt.timezone.utc)
    with db.tx() as con:
        cur = con.execute("INSERT INTO price_overrides (sku, store, price, reason, created_by, created_at, expires_at) "
                          "VALUES (?,?,?,?,?,?,?)",
                          (o.sku, o.store, o.price, o.reason, who.actor, now.isoformat(),
                           (now + dt.timedelta(minutes=o.valid_minutes)).isoformat()))
        oid = cur.lastrowid
        record(con, who, "price.override.create", f"{o.sku}@{o.store}",
               {"override_id": oid, "old_base_price": p.base_price, "new_price": o.price, "reason": o.reason},
               request.state.request_id)
        emit(con, "price.override.created", {"override_id": oid, "sku": o.sku, "store": o.store, "price": o.price})
    return {"override_id": oid, "created_by": who.actor, "expires_in_minutes": o.valid_minutes}


@router.get("/admin/audit", tags=["admin"])
def audit(entity: Optional[str] = None, limit: int = Query(100, ge=1, le=1000),
          _: Principal = Depends(require("audit:read"))):
    con = db.connect()
    try:
        q, args = "SELECT * FROM audit_log", []
        if entity:
            q += " WHERE entity=?"; args.append(entity)
        rows = con.execute(q + " ORDER BY audit_id DESC LIMIT ?", args + [limit]).fetchall()
    finally:
        con.close()
    return [{**dict(r), "detail": json.loads(r["detail"])} for r in rows]


# ---------------------------------------------------------------- integration feed
@router.get("/integration/events", tags=["integration"])
def events(after_id: int = Query(0, ge=0), limit: int = Query(100, ge=1, le=1000),
           _: Principal = Depends(require("integration:read"))):
    """ERP and warehouse poll this feed (or a relay pushes it to a queue): orders arrive in seconds, not next morning."""
    con = db.connect()
    try:
        rows = con.execute("SELECT * FROM outbox WHERE event_id > ? ORDER BY event_id LIMIT ?",
                           (after_id, limit)).fetchall()
    finally:
        con.close()
    items = [{"event_id": r["event_id"], "at": r["at"], "type": r["type"], "payload": json.loads(r["payload"])}
             for r in rows]
    return {"events": items, "next_after_id": items[-1]["event_id"] if items else after_id}
