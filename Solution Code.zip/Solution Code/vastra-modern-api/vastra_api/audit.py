"""Append-only audit trail and transactional outbox helpers."""
import datetime as dt
import json


def _now():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def record(con, principal, action: str, entity: str, detail: dict, request_id: str | None):
    """Write inside the caller's transaction, so the change and its audit row commit together."""
    con.execute("INSERT INTO audit_log (at, actor, client, action, entity, detail, request_id) VALUES (?,?,?,?,?,?,?)",
                (_now(), principal.actor, principal.client, action, entity, json.dumps(detail), request_id))


def emit(con, event_type: str, payload: dict):
    """Outbox event, committed atomically with the business change; consumers read /v1/integration/events."""
    con.execute("INSERT INTO outbox (at, type, payload) VALUES (?,?,?)", (_now(), event_type, json.dumps(payload)))


def active_override(con, sku: str, store: str | None):
    if not store:
        return None
    r = con.execute("SELECT * FROM price_overrides WHERE sku=? AND store=? AND expires_at > ? "
                    "ORDER BY override_id DESC LIMIT 1", (sku, store, _now())).fetchone()
    return dict(r) if r else None
