"""The new service's own database. It owns stock, orders, payments, idempotency, audit and the outbox.

SQLite keeps the lab runnable anywhere; the schema is plain SQL and moves to PostgreSQL/MySQL unchanged.
"""
import os
import sqlite3
from contextlib import contextmanager

from vastra_api import config

SCHEMA = """
CREATE TABLE IF NOT EXISTS stock_levels (
    sku TEXT PRIMARY KEY,
    on_hand INTEGER NOT NULL,
    reserved INTEGER NOT NULL DEFAULT 0,
    updated_at TEXT NOT NULL,
    CHECK (on_hand >= 0), CHECK (reserved >= 0), CHECK (reserved <= on_hand)
);
-- Every stock change is an event; (source, ref) is unique so a re-sent POS/WMS event is applied once.
CREATE TABLE IF NOT EXISTS stock_events (
    event_id INTEGER PRIMARY KEY AUTOINCREMENT,
    sku TEXT NOT NULL, delta INTEGER NOT NULL, kind TEXT NOT NULL,
    source TEXT NOT NULL, ref TEXT NOT NULL, at TEXT NOT NULL,
    UNIQUE (source, ref)
);
CREATE TABLE IF NOT EXISTS orders (
    order_id TEXT PRIMARY KEY, created_at TEXT NOT NULL, channel TEXT NOT NULL, sku TEXT NOT NULL,
    qty INTEGER NOT NULL, unit_price INTEGER NOT NULL, total INTEGER NOT NULL, status TEXT NOT NULL,
    pricing_version TEXT NOT NULL, delivery_days INTEGER, delivery_estimated INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS payments (
    idempotency_key TEXT PRIMARY KEY, order_id TEXT NOT NULL, amount INTEGER NOT NULL,
    status TEXT NOT NULL, charge_id TEXT, reason TEXT, at TEXT NOT NULL
);
-- Stored responses for Idempotency-Key replays.
CREATE TABLE IF NOT EXISTS idempotency (
    key TEXT PRIMARY KEY, client TEXT NOT NULL, request_hash TEXT NOT NULL,
    status_code INTEGER, response TEXT, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS price_overrides (
    override_id INTEGER PRIMARY KEY AUTOINCREMENT, sku TEXT NOT NULL, store TEXT,
    price INTEGER NOT NULL, reason TEXT NOT NULL, created_by TEXT NOT NULL,
    created_at TEXT NOT NULL, expires_at TEXT NOT NULL
);
-- Append-only: who did what, from which client, with which request id.
CREATE TABLE IF NOT EXISTS audit_log (
    audit_id INTEGER PRIMARY KEY AUTOINCREMENT, at TEXT NOT NULL, actor TEXT NOT NULL, client TEXT NOT NULL,
    action TEXT NOT NULL, entity TEXT NOT NULL, detail TEXT NOT NULL, request_id TEXT
);
-- Transactional outbox: written in the same transaction as the order, read by ERP/WMS (replaces the nightly CSV).
CREATE TABLE IF NOT EXISTS outbox (
    event_id INTEGER PRIMARY KEY AUTOINCREMENT, at TEXT NOT NULL, type TEXT NOT NULL, payload TEXT NOT NULL
);
"""


def connect() -> sqlite3.Connection:
    path = config.settings.db_path
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    con = sqlite3.connect(path, timeout=5, isolation_level=None, check_same_thread=False)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA journal_mode=WAL")
    con.execute("PRAGMA foreign_keys=ON")
    return con


@contextmanager
def tx():
    """One short transaction. BEGIN IMMEDIATE takes the write lock up front, so stock updates cannot race."""
    con = connect()
    try:
        con.execute("BEGIN IMMEDIATE")
        yield con
        con.execute("COMMIT")
    except Exception:
        con.execute("ROLLBACK")
        raise
    finally:
        con.close()


def init():
    con = connect()
    con.executescript(SCHEMA)
    con.close()
